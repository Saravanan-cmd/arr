
import java.util.Arrays;
public class Arr6{
public static void main(String[] args){
	    int arr[]= {10,87,67,59,20,80,60};
	    int l=arr.length;
	    Arrays.sort(arr);
	    for(int i=0;i<arr.length;i++)
	        System.out.println(arr[i]);
		
	}

}